//
//  GameViewController.swift
//  SnakeFB
//
//  Created by Maryam Aldairi on 6/27/19.
//  Copyright © 2019 Maryam Aldairi. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit
import FBSDKLoginKit
import FBSDKShareKit
import FBSDKCoreKit

class GameViewController: UIViewController,LoginButtonDelegate {
    
    
    @IBOutlet var lblStatus: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let btnFBLogin = FBLoginButton()
        btnFBLogin.permissions = ["public_profile"]
        btnFBLogin.delegate = self
        
        btnFBLogin.center = view.center
        self.view.addSubview(btnFBLogin)
        
        if AccessToken.current != nil {
            self.lblStatus.text = "User Logged In"
        }else{
            self.lblStatus.text = "User Logged Out"
        }
          
        }
        
        
    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        if error != nil{
            self.lblStatus.text = error?.localizedDescription
        }else if result!.isCancelled {
            self.lblStatus.text = "User Cancelled Login"
        }else{
            self.lblStatus.text = "User Logged In"
        }
    }
    
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
        self.lblStatus.text = "User Logged Out"
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
}

